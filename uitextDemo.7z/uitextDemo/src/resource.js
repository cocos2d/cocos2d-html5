var res = {
    CloseNormal_png : "res/CloseNormal.png",
    CloseSelected_png : "res/CloseSelected.png",
    BuildShipContentPage_json: "res/BuildShipContentPage.json"
};

var g_resources = [];
for (var i in res) {
    g_resources.push(res[i]);
}