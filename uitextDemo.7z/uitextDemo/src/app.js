
var HelloWorldLayer = cc.Layer.extend({
    sprite:null,
    _text: null,
    _buildShipWindow: null,

    ctor:function () {
        this._super();
        var self = this;
        var size = cc.winSize;
        var closeItem = new cc.MenuItemImage(
            res.CloseNormal_png,
            res.CloseSelected_png,
            function () {
                if (null === self._buildShipWindow) {
                    self._buildShipWindow = new BuildShipWindow();
                    self.addChild(self._buildShipWindow);
                    self._buildShipWindow.onShowNotify();
                }
                cc.log("Menu is clicked!");
            }, this);
        closeItem.attr({
            x: size.width - 20,
            y: 20,
            anchorX: 0.5,
            anchorY: 0.5
        });

        var menu = new cc.Menu(closeItem);
        menu.x = 0;
        menu.y = 0;
        this.addChild(menu, 1);
        return true;
    }
});

var HelloWorldScene = cc.Scene.extend({
    onEnter:function () {
        this._super();
        var layer = new HelloWorldLayer();
        this.addChild(layer);
    }
});

