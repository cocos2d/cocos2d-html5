/**
 * Created by malloyzhu on 2015/7/14.
 */

/**
 * 造船厂
 */

var BuildShipWindow = cc.Node.extend({
    _shipDataList: [],
    _pageView: null,

    ctor: function () {
        this._super();
        this.setAnchorPoint(0, 0);

        this._shipDataList.push({level: 1, name: "海上君王号", health: 100, attackBonus: 11, capacity: 100, durability: 100});
        this._shipDataList.push({level: 4, name: "歌德号", health: 100, attackBonus: 11, capacity: 100, durability: 100});
        this._shipDataList.push({level: 7, name: "阿拉斯号", health: 100, attackBonus: 11, capacity: 100, durability: 100});

        this._pageView = new ccui.PageView();
        this._pageView.setBackGroundColorType(ccui.Layout.BG_COLOR_SOLID);
        this._pageView.setBackGroundColor(cc.color(122, 122, 122));
        this._pageView.setContentSize(400, 540);
        this.addChild(this._pageView);
    },

    onShowNotify: function () {
        var rootJson = ccs.load(res.BuildShipContentPage_json);
        var rootNode = rootJson.node.getChildByName("contentPanel");
        for (var i in this._shipDataList) {
            var rootNodeClone = rootNode.clone();
            rootNodeClone.setBackGroundColorType(ccui.Layout.BG_COLOR_NONE);
            var page = new ccui.Layout();
            page.addChild(rootNodeClone);
            var shipNameText = ccui.helper.seekWidgetByName(rootNodeClone, "_shipNameText");
            shipNameText.ignoreContentAdaptWithSize(true);
            shipNameText.setString(this._shipDataList[i].name);
            this._pageView.addPage(page);
        }
    }
});

